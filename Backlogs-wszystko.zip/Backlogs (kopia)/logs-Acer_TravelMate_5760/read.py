# -*- coding: utf-8 -*-
import sys, os

path = "."
files = ['pisak.log']
files2 = [item for item in os.listdir(path) if "pisak.log." in item]
files2.sort(key = lambda x: int(x.split('.')[-1]))
files.extend(files2)

first_save = "unique_logs"
sound_file = "sound_logs"
scanning_file = "scanning_logs"
signal_file = "signal_logs"
rest_file = "rest_logs"

unique = []

with open(sound_file, 'w') as soundFile:
    with open(scanning_file, 'w') as scanningFile:
        with open(signal_file, 'w') as signalFile:
            with open(rest_file, 'w') as restFile:
                for f in files:
                    soundFile.write("\n\n=============================== " + f + " ===============================\n\n")
                    scanningFile.write("\n\n=============================== " + f + " ===============================\n\n")
                    signalFile.write("\n\n=============================== " + f + " ===============================\n\n")
                    restFile.write("\n\n=============================== " + f + " ===============================\n\n")                        

                    line_number=0
                    with open(f, 'r') as log:
                        for line in log.readlines():
                            line_number += 1
                            ending = line.split("-")[-1]

                            if ending not in unique:
                                unique.append(ending)
                                
                                if "pisak.dirs" in line: 
                                    soundFile.write(line)
                                elif "pisak.scanning" in line:
                                    scanningFile.write(line)
                                elif "pisak.signals" in line:
                                    signalFile.write(line)
                                else:
                                    restFile.write(line)
                                    
                            elif "Traceback" in ending:
                                restFile.write("\nTraceback line: " + str(line_number) + '\n')
