# -*- coding: utf-8 -*-
import sys, os

path = "."
files = ['pisak.log']
files2 = [item for item in os.listdir(path) if "pisak.log." in item]
files2.sort(key = lambda x: int(x.split('.')[-1]))
files.extend(files2)

for f in files:
	with open(f, 'r') as log:
		for line in log.readlines():
			if '/home/' in line and 'radoslaw' not in line:
				print line
                       
