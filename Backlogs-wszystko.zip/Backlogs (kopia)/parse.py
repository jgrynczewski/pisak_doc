# -*- coding: utf-8 -*-
import sys, os

unique = []

path = "."
files = [item for item in os.listdir(path) if item.startswith("logs")]

names = ['radoslaw', 'kuba', 'przemek', 'michal', 'krzysztof', 'piotr', 'micha', 'asia']

sound_file = "sound_logs"
scanning_file = "scanning_logs"
signal_file = "signal_logs"
rest_file = "rest_logs"
traceback_file = "traceback_logs"

unique = []
unique_sounds = [] 
unique_signals = [] 
unique_scannings = [] 

flag = "unique"

with open(rest_file, 'w') as newRestFile:
    with open(traceback_file, 'w') as tracebackFile:
        for f in files:
            line_number = 0
            
            newRestFile.write("\n\n------------------------------------------------------------------------------------------------------------------------\n")
            newRestFile.write("------------------------------------------ " + f + " ------------------------------------------\n")
            newRestFile.write("------------------------------------------------------------------------------------------------------------------------\n")
            
            tracebackFile.write("\n\n------------------------------------------------------------------------------------------------------------------------\n")
            tracebackFile.write("------------------------------------------ " + f + " ------------------------------------------\n")
            tracebackFile.write("------------------------------------------------------------------------------------------------------------------------\n")
            
            with open(f + "/" + rest_file, 'r') as restFile:
                
                for log in restFile.readlines():

                    # jeżeli jesteśmy w trakcie czytania tracebacku i natrafiamy na datę na początku linijki 
                    # to oznacza, że traceback się skończył i wczytaliśmy następny log (który może być
                    # kolejnym tracebackiem.
                    if (log.split('-')[0] == "2016" or log.split('-')[0] == "2015") and flag == "traceback":
                        split1 = log.split('-')[-1]
                        split2 = split1.split('/')
                        
                        removedElements = [item for item in split2 if item not in names]
                        
                        cleanLine = "/".join(removedElements)
                    
                        # Co jeżeli ten log też jest kolejnym tracebackiem
                        if "Traceback" in log:
                            tracebackFile.write("\n"+log)
                            
                        # a co jeżeli nie jest tracebackiem
                        elif cleanLine not in unique:
                            unique.append(cleanLine)
                            newRestFile.write("\n"+log)
                            flag = "unique"
                                            
                    # jeżeli mamy datę na początku linijki i linijka zawiera słowo 'Traceback'
                    # to oznacza, że zaczynamy czytać traceback
                    elif (log.split('-')[0] == "2016" or log.split('-')[0] == "2015") and "Traceback" in log:
                        flag = "traceback"
                        tracebackFile.write(log)

                    # zwykły log
                    elif (log.split('-')[0] == "2016" or log.split('-')[0] == "2015"):
                        split1 = log.split('-')[-1]
                        split2 = split1.split('/')
                        
                        removedElements = [item for item in split2 if item not in names]
                        
                        cleanLine = "/".join(removedElements)
                        
                        if cleanLine not in unique:
                            unique.append(cleanLine)
                            newRestFile.write(log)
                            flag = "unique"

                    # znacznik pliku
                    elif log.startswith("==="):
                        tracebackFile.write(log)
                        newRestFile.write(log)
                    
                    # jeżeli jesteśmy w trakcie czytania tracebacku (i nie jest to następny log
                    # bo gdyby był wykonany zostałby drugi if.
                    elif (flag == "traceback"):
                        tracebackFile.write(log)
                    
                    # w innym wypadku nie wiem co to jest - umieszczam w rest_file
                    elif log.isalpha():
                        split1 = log.split('-')[-1]
                        split2 = split1.split('/')
                        
                        removedElements = [item for item in split2 if item not in names]
                        
                        cleanLine = "/".join(removedElements)

                        if cleanLine not in unique:
                            unique.append(cleanLine)
                            newRestFile.write(log)

with open(sound_file, 'w') as newSoundFile:
    for f in files:
        line_number = 0


        newSoundFile.write("\n\n------------------------------------------------------------------------------------------------------------------------\n")
        newSoundFile.write("------------------------------------------ " + f + " ------------------------------------------\n")
        newSoundFile.write("------------------------------------------------------------------------------------------------------------------------\n")

        with open(f + "/" + sound_file, 'r') as soundFile:

            for log in soundFile.readlines():

                if log.startswith("==="):
                    newSoundFile.write(log)
                else:
                    split1 = log.split('-')[-1]
                    split2 = split1.split('/')

                    removedElements = [item for item in split2 if item not in names]
                    
                    cleanLine = "/".join(removedElements)

                    if cleanLine not in unique_sounds:
                        unique_sounds.append(cleanLine)
                        newSoundFile.write(log)

with open(scanning_file, 'w') as newScanningFile:
    for f in files:
        line_number = 0

        newScanningFile.write("\n\n------------------------------------------------------------------------------------------------------------------------\n")
        newScanningFile.write("------------------------------------------ " + f + " ------------------------------------------\n")
        newScanningFile.write("------------------------------------------------------------------------------------------------------------------------\n")

        with open(f + "/" + scanning_file, 'r') as scanningFile:

            for log in scanningFile.readlines():

                if log.startswith("==="):
                    newScanningFile.write(log)

                else:
                    split1 = log.split('-')[-1]
                    split2 = split1.split('/')

                    removedElements = [item for item in split2 if item not in names]
                    
                    cleanLine = "/".join(removedElements)
                
                    if cleanLine not in unique_scannings:
                        unique_scannings.append(cleanLine)
                        newScanningFile.write(log)


with open(signal_file, 'w') as newSignalFile:
    for f in files:
        line_number = 0

        newSignalFile.write("\n\n------------------------------------------------------------------------------------------------------------------------\n")
        newSignalFile.write("------------------------------------------ " + f + " ------------------------------------------\n")
        newSignalFile.write("------------------------------------------------------------------------------------------------------------------------\n")

        with open(f + "/" + signal_file, 'r') as signalFile:

            for log in signalFile.readlines():

                if log.startswith("==="):
                    newSignalFile.write(log)

                else:
                    split1 = log.split('-')[-1]
                    split2 = split1.split('/')

                    removedElements = [item for item in split2 if item not in names]

                    cleanLine = "/".join(removedElements)

                    if cleanLine not in unique_signals:
                        unique_signals.append(cleanLine)
                        newSignalFile.write(log)
